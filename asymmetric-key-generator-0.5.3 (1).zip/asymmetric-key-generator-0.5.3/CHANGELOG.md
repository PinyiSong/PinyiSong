# CHANGELOG

## v0.5.3
- Update dependencies

## v0.5.2
- Update dependencies

## v0.5.1
- Update dependencies

## v0.5.0
- Default for `ed25519` keys
- Change app name

## v0.4.0
- Add support for `ed25519` keys

## v0.3.1
- Fix tooltip on canceled save
- Update dependencies

## v0.3.0
- Restructured files
- Added error message on not saved key

## v0.2.0
- Fixed an error in macOS for when the window is reopened
- Allow only `2048` and `4096` bits keys generation
- Improved the handling of download dialog.

## v0.1.1
- First release
